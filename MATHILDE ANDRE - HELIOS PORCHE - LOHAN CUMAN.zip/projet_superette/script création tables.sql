create table Produit(
	nomProd varchar(40),
	quteOpti integer,
	quteMin integer,
	categorie varchar(20),
	description varchar(400));
	
create table Vente(
	id_Vente  integer primary key,
	dateVente date,
	num_lot integer references ProduitStocke,
	nomProd varchar(40) references Produit,
	prixFinal numeric(6,2),
	quantite integer,
	commentaire varchar(400));

create table ProduitStocke(
	num_lot integer,
	nomProd varchar(40) references Produit,
	qute integer,
	prixVente numeric(6,2),
	idAchat integer references Achat);

create table Achat(
	idAchat integer primary key,
	idContrat integer references Contrat,
	prix numeric(6,2),
	dateAchat date,
	datePeremption date);

create table Contrat(
	idContrat integer primary key,
	prix numeric(6,2),
	nomProd varchar(40) references Produit,
	SIRET integer references Entreprise,
	description varchar(400),
	dateDebut date,
	dateFin date);
	
create table Entreprise(
	SIRET INTEGER primary key,
	nomEntreprise varchar(100),
	mail varchar(200),
	adresse varchar (500));
	
create table FonctionContact(
	SIRET integer references Entreprise,
	telContact varchar(15) references Contact,
	fonction varchar (40));

create table Contact(
	telContact varchar(15) primary key,
	nom varchar(40),
	prenom varchar(40),
	email varchar(200));
	
