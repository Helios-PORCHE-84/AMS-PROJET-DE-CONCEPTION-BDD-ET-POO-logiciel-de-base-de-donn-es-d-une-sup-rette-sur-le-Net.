

package superete;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProduitStocke implements Ajouter, Modifier, Supprimer {
	public int num_lot;
	public String nom;
	public int qute; 
	public double prixVente;
	public int idAchat;
	//quté = nombre d'achetés - nombre de  vendus
	//qd produit périme -> Vente à 0euro


	public ProduitStocke() {
		super();
		num_lot = -1;
		nom = "";
		qute = 0;
		prixVente=-1;
		idAchat = -1;
	}	

	public int ajouter(Connection conn) {

		String sql = "INSERT INTO ProditStocke(num_lot, nomProd, qute, prixVente, idAchat) VALUES(?,?,?,?,?)";
		try ( PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
			pstmt.setInt(1, num_lot);
			pstmt.setString(2,nom); 
			pstmt.setInt(3, qute); 
			pstmt.setDouble(4, prixVente); 
			pstmt.setDouble(5, idAchat); ;
			int insertedRow = pstmt.executeUpdate(); //remplace les ? par les champs
			if (insertedRow > 0) { //si ça marche on return 1
				ResultSet rs = pstmt.getGeneratedKeys(); 
				if (rs.next()) {
					return rs.getInt(1);
				}
			} 
		} catch (SQLException e) {	
		}
		return 0;

	}

	public void demandeAjout(Connection conn) {

		Scanner scanner = new Scanner(System.in);
		int fini = 0;
		while ( fini == 0) {
			System.out.println("Vous ajoutez un Produit dans les Stocks \n\n");
			System.out.println("Quel est le numéro de lot du(des) produit(s) : ");
			num_lot  = scanner.nextInt();
			System.out.println("\n Quel est le nom du produit : ");
			nom  = scanner.nextLine();
			System.out.println("\n Quelle est la quantité : ");
			qute = scanner.nextInt();
			System.out.println("\n Quelle est le prix de vente du produit : ");
			prixVente  = scanner.nextDouble();
			System.out.println("\n Quel est l'identifiant de l'achat : ");
			idAchat  = scanner.nextInt();
			System.out.println("\n Si vous voullez recomencer entrez 0 sinon entrez 1 pour valider:");
			fini = scanner.nextInt();
		}
		ajouter(conn);
	}
	public void supprimer (Connection conn) {
		Scanner scanner = new Scanner(System.in);
		String sql;
		PreparedStatement pstmt;
		System.out.println("Quel est le numéro de lot du produit stocké àcsupprimer ? \n");
		num_lot  = scanner.nextInt();
		System.out.println("Quel est nom du produit stocké à supprimer ? \n");
		nom  = scanner.nextLine();
		sql = "DELETE FROM ProduitStocke WHERE num_lot = "+num_lot+"AND nomProd ="+nom+";";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	
	}


	public void modifier (Connection conn) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Bienvenue sur l'espace modification Produit !\n");
		System.out.println("Que  voullez vous modifier ? Renter le numéro corespondant.\n\n"); 
		System.out.println("0 : Retourner a l'accueil  \n");
		System.out.println("1 : Quantité \n");
		System.out.println("2 : Prix final \n"); 
		System.out.println("3 : commentaire \n");   

		int NUM = scanner.nextInt();

		System.out.println("\n Quel est le numéro de lot : "); 
		num_lot = scanner.nextInt();

		System.out.println("\n Quel est le nom du produit : "); 
		nom = scanner.nextLine();
		
		String sql;
		PreparedStatement pstmt;

		switch (NUM ) {
		case 0 : Afficher x = new Afficher();
		x.affichagePrinc(conn);
		break;
		case 1 : 
			System.out.println("Quel est la nouvelle quantité \n");	 
			qute = scanner.nextInt();
			sql = "UPDATE ProduitStocke SET quantite = " + qute +" WHERE num_lot = "+num_lot+"AND nomProd ="+nom+";";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 

			break;
		case 2 : 
			System.out.println("Quel est le nouveau prix de vente \n");	 
			prixVente = scanner.nextInt();
			sql = "UPDATE ProduitStocke SET prixVente= " + prixVente+ " WHERE num_lot = "+num_lot+"AND nomProd ="+nom+";";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 

			break;
		}
		

	}
}
