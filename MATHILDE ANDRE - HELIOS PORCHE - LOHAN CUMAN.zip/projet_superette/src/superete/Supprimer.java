package superete;

import java.sql.Connection;

public interface Supprimer {
	public void supprimer(Connection conn);
}
