package superete;

import java.sql.*;

import java.util.Scanner;

public class Contacts implements Ajouter, Modifier, Supprimer {
	public String Nom;
	public String Prenom;
	public int tel;
	public String mail;
	

	

public Contacts() {
		super();
		Nom = "";
		Prenom = "";
		tel = -1;
		mail= "";
	}
public int ajouter(Connection conn) {
	Fonction x = new Fonction();
	x.demandeAjout(conn);
	String sql = "INSERT INTO Contact(nom, prenom, telContact, email) VALUES(?,?,?,?)";
	try ( PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
		pstmt.setString(1, Nom);
		pstmt.setString(2,Prenom); 
		pstmt.setInt(3, tel); 
		pstmt.setString(4, mail); 
		
		int insertedRow = pstmt.executeUpdate(); //remplace les ? par les champs
		if (insertedRow > 0) { //si ça marche on return 1
			ResultSet rs = pstmt.getGeneratedKeys(); 
			if (rs.next()) {
				return rs.getInt(1);
			}
			} 
		} catch (SQLException e) {	
	}
	return 0;
	 
}
public void demandeAjout(Connection conn) {

Scanner scanner = new Scanner(System.in);
int fini = 0;
while ( fini == 0) {
System.out.println("Vous ajoutez un contact \n\n");
System.out.println("Quel est le nom du contact : ");
Nom  = scanner.nextLine();
System.out.println("\n Quel est le prénom du contact : ");
Prenom  = scanner.nextLine();
System.out.println("\n Quelle est le numéro de téléphone du contact: ");
tel = scanner.nextInt();
System.out.println("\n Quelle est l'adresse mail du contact : ");
mail = scanner.nextLine();

System.out.println("\n Si vous voullez recomencer entrez 0 sinon entrez 1 pour valider:");
fini = scanner.nextInt();
}
ajouter(conn);
}

public void supprimer (Connection conn) {
	Scanner scanner = new Scanner(System.in);
	String sql;
	PreparedStatement pstmt;
	System.out.println("Quel est le numéro de telephone du contact a supprimer ? \n");
	tel  = scanner.nextInt();
	sql = "DELETE FROM Contact WHERE telConatact = "+tel+";";
	try {
		pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	} 
	Fonction x = new Fonction();
	x.telContact = tel;
	x.supprimer(conn);
	
	}

public void modifier (Connection conn) {
	Scanner scanner = new Scanner(System.in);

	System.out.println("Bienvenue sur l'espace modification Contact !\n");
	System.out.println("Que  voullez vous modifier ? Renter le numéro corespondant.\n\n"); 
	System.out.println("0 : Retourner a l'accueil  \n");
	System.out.println("1 : nom  \n");
	System.out.println("2 : prenom  \n"); 
	System.out.println("3 : mail  \n"); 
	System.out.println("4 : tel  \n"); 
	System.out.println("5 : fonction \n"); 
	int NUM = scanner.nextInt();
	
	System.out.println("\n Quel est le num de tel du contact a modifier ? "); 
	int telv2   = scanner.nextInt();
	String sql;
	 PreparedStatement pstmt;
	 
	switch (NUM ) {
	case 0 : Afficher x = new Afficher();
			x.affichagePrinc(conn);
	break;
	case 1 : 
		System.out.println("Quel est le nouveau nom \n");	 
		Nom  = scanner.nextLine();
		sql = "UPDATE Contact SET nom = " + Nom  + "WHERE telContact = "+ telv2 +" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 2 : 
		System.out.println("Quelle est le nouveau prenom \n");
		Prenom  = scanner.nextLine();
		
		sql = "UPDATE Contact SET prenom = '" + Prenom + "' WHERE telContact = "+ telv2 +" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 3 : 
		System.out.println("Quelle est le nouveau mail \n");
		mail = scanner.nextLine();
		
		sql = "UPDATE Contact SET mail = '" + mail + "' WHERE telContact = "+ telv2 +" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 4 : 
		System.out.println("Quelle est le nouveau num de tel  \n");
		tel = scanner.nextInt();
		
		sql = "UPDATE Contact SET telContact = " + tel + "WHERE telContact = "+ telv2 +" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		sql = "UPDATE FonctionContact SET telContact = " + tel + "WHERE telContact = "+ telv2 +" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 5 : 
		System.out.println("Quelle est la nouvelle fonction \n");
		String fonction = scanner.nextLine();
		
		sql = "UPDATE FonctionContact SET fonction = '" + fonction + "'WHERE telContact = "+ telv2 +" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	}
	
	}
}