package superete;

import java.sql.*;
import java.util.Properties;
import java.util.Scanner;

public class Test {
	//uapv2401632
	//TuPDSF
    public static void main(String[] args) throws SQLException {
    	Connexion connection = new Connexion();
    	  Scanner scanner = new Scanner(System.in);

        if (connection.meConnecter() != null) {
            System.out.println("Connexion à la base de données établie avec succès !");
            
            Connection conn ;
       	 Properties props = new Properties();
            props.setProperty("user", connection.user);
            props.setProperty("password", connection.pass);
            String url = "jdbc:postgresql://pedago.univ-avignon.fr:5432/etd";
            conn = DriverManager.getConnection(url, props);
            
            Afficher x = new Afficher();
            x.affichagePrinc(conn);            
        } else {
            System.out.println("Impossible de se connecter à la base de données.");
        }
       scanner.close();
    }
}