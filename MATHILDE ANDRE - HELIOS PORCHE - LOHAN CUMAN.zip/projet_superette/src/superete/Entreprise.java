package superete;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Scanner;

public class Entreprise implements Ajouter, Modifier, Supprimer {
	public String nom;
	public String mail;
	public String adresse;
	public HashMap<String,Integer> listeProditsProposes;
	public int siret;


public Entreprise() {
		super();
		nom = "";
		mail = "";
		adresse = "";
		listeProditsProposes = null;
		siret = -1;
	}

public int ajouter(Connection conn) {

	String sql = "INSERT INTO Entreprise(SIRET, nomEntreprise, mail, adresse) VALUES(?,?,?,?)";
	try ( PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
		pstmt.setInt(1, siret);
		pstmt.setString(2,nom); 
		pstmt.setString(3, mail); 
		pstmt.setString(4,adresse);

		
		int insertedRow = pstmt.executeUpdate(); //remplace les ? par les champs
		if (insertedRow > 0) { //si ça marche on return 1
			ResultSet rs = pstmt.getGeneratedKeys(); 
			if (rs.next()) {
				return rs.getInt(1);
			}
			} 
		} catch (SQLException e) {	
	}
	return 0;
	 
}
public void demandeAjout(Connection conn) {

Scanner scanner = new Scanner(System.in);
int fini = 0;
while ( fini == 0) {
System.out.println("Vous ajoutez une entreprise \n\n");
System.out.println("Quel est le nom de l'entreprise: ");
nom = scanner.nextLine();
System.out.println("\n Quelle est l'adresse mail de l'entreprise: ");
mail  = scanner.nextLine();
System.out.println("\n Quelle est l'adresse de l'entreprise : ");
adresse = scanner.nextLine();
System.out.println("\n Quel est le numéro SIRET de l'entreprise : ");
siret = scanner.nextInt();
System.out.println("\n Si vous voullez recomencer entrez 0 sinon entrez 1 pour valider:");
fini = scanner.nextInt();
if (fini == 0) {
	nom = null;
	mail = null;
	adresse = null;
	siret = -1;
}
}
ajouter(conn);
}

public void modifier (Connection conn) {
	Scanner scanner = new Scanner(System.in);

	System.out.println("Bienvenue sur l'espace modification Entreprise !\n");
	System.out.println("Que vollez vous modifier ? Renter le numéro corespondant.\n\n"); 
	System.out.println("0 : Retourner a l'accueil  \n");
	System.out.println("1 : Nom \n");
	System.out.println("2 : E-Mail \n"); 
	System.out.println("3 : Adresse \n"); 
 
	int NUM = scanner.nextInt();
	
	System.out.println("\n Quel est le numéro de SIRET de l'entreprise: "); 
	siret   = scanner.nextInt();
	String sql;
	 PreparedStatement pstmt;
	 
	switch (NUM ) {
	case 0 : Afficher x = new Afficher();
			x.affichagePrinc(conn);
	break;
	case 1 : 
		System.out.println("Quel est le nouveaau nom \n");	 
		nom  = scanner.nextLine();
		sql = "UPDATE Entreprise SET nomEntreprise = '" + nom + "'WHERE SIRET = "+ siret+" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 2 : 
		System.out.println("Quelle est la nouvelle adresse mail \n");
		mail  = scanner.nextLine();
		sql = "UPDATE Entreprise SET mail = '" + mail + "' WHERE SIRET = "+ siret+" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 3 :  
		System.out.println("Quelle est la nouvelle adresse \n");
		adresse  = scanner.nextLine();
		sql = "UPDATE Entreprise SET adresse = '" + adresse + "' WHERE SIRET = "+ siret+" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	break;
	}

	}

	public void supprimer (Connection conn) {
		Scanner scanner = new Scanner(System.in);
		String sql;
		PreparedStatement pstmt;
		System.out.println("Quel est le SIRET de l'entreprise à supprimer? \n");
		siret = scanner.nextInt();
		sql = "DELETE FROM Entreprise WHERE SIRET = "+siret+";";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 

	}

}