package superete;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Fonction implements Ajouter, Supprimer {
	public int SIRET;
	public int telContact;
	public String fonction;
	
	
	public int ajouter(Connection conn) {
		
		String sql = "INSERT INTO FonctionContact(SIRET, telContact, fonction) VALUES(?,?,?)";
		try ( PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
			pstmt.setInt(1, SIRET);
			pstmt.setInt(2,telContact); 
			pstmt.setString(3, fonction); 
			
			int insertedRow = pstmt.executeUpdate(); //remplace les ? par les champs
			if (insertedRow > 0) { //si ça marche on return 1
				ResultSet rs = pstmt.getGeneratedKeys(); 
				if (rs.next()) {
					return rs.getInt(1);
				}
				} 
			} catch (SQLException e) {
				return 0;
		}
		return 0;
		 
	}
	public void demandeAjout(Connection conn) {

	Scanner scanner = new Scanner(System.in);
	int fini = 0;
	while ( fini == 0) {
	System.out.println("Vous ajoutez une fonction au contact par rapport à son entreeprise\n\n");
	System.out.println("Quel est le numéro de SIRET de l'entreprise: ");
	SIRET  = scanner.nextInt();
	System.out.println("\n Quel est le numéro de téléphone du contact : ");
	telContact = scanner.nextInt();
	System.out.println("\n Quelle est sa fonction au sein de l'entreprise: ");
	fonction = scanner.nextLine();
	System.out.println("\n Si vous voullez recomencer entrez 0 sinon entrez 1 pour valider:");
	fini = scanner.nextInt();
	}
 ajouter(conn);
	}
	
	public void supprimer (Connection conn) {
		Scanner scanner = new Scanner(System.in);
		String sql;
		PreparedStatement pstmt;
		sql = "DELETE FROM FonctionContact WHERE  telContact = "+telContact+";";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		}

	}
