package superete;

import java.util.Scanner;
import java.util.Properties;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class Connexion {
	Connection connect;
	String user;
	String pass;
	
	public Connexion() {
		super();
		this.connect = null;
	}


    public Connection meConnecter() { 
        Properties props = new Properties(); 
    	String dataBase = "etd";
       String url = "jdbc:postgresql://pedago.univ-avignon.fr:5432/" + dataBase;
    	try { 
        	
            Scanner scanner = new Scanner(System.in);

            System.out.println("Entrez votre nom d'utilisateur:" );
           user = scanner.nextLine();
            props.setProperty("user", user); 
            
            System.out.println("Entrez votre mot de passe :");
             pass = scanner.nextLine();
            props.setProperty("password", pass);
            
         
            
            //connexion
            connect = DriverManager.getConnection(url, props);
            
            //connexion ok ?
            if (connect != null) {
                System.out.println("Connexion réussie !");
            } else {
                System.out.println("Connexion échouée !");
            }
            System.out.println("Tentative de connexion avec l'utilisateur : " + user);
            connect = DriverManager.getConnection(url, props);
            System.out.println("Connexion réussie !");
            
        } catch (SQLException e) {
        	System.out.println("Erreur lors de la connexion : " + e.getMessage());
            System.out.println("URL utilisée : " + url);
            System.out.println("Utilisateur utilisé : " + props.getProperty("user"));
        } catch (Exception e) {
            System.out.println("Erreur :" + e.getMessage());
        }
        return connect; 
    }


}