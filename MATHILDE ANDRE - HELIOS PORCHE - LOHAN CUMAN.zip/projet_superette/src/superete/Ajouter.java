package superete;

import java.sql.Connection;

public interface Ajouter {
	public int ajouter(Connection connection); 
	public void demandeAjout(Connection connection);
}