package superete;

import java.sql.*;
import java.util.Scanner;

public class Produit implements Ajouter, Modifier, Supprimer {
	public String nom;
	public String description;
	public int quteMin; 
	public int quteOpti;
	public Categorie categorie;




	public Produit() {
		super();
		nom = "";
		description = "";
		quteMin = -1;
		quteOpti = -1;
		categorie = null;
	}

	public int ajouter(Connection conn) {

		String sql = "INSERT INTO Produit(nomProd, description, quteMin, quteOpti, categorie) VALUES(?,?,?,?,?)";
		try ( PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
			pstmt.setString(1, nom);
			pstmt.setString(2, description); 
			pstmt.setInt(3, quteMin); 
			pstmt.setInt(4, quteOpti); 
			pstmt.setString(5,categorie.toString());
			int insertedRow = pstmt.executeUpdate(); //remplace les ? par les champs
			if (insertedRow > 0) { //si ça marche on return 1
				ResultSet rs = pstmt.getGeneratedKeys(); 
				if (rs.next()) {
					return rs.getInt(1);
				}
			} 
		} catch (SQLException e) {	
		}
		return 0;

	}
	public void demandeAjout(Connection conn) {

		Scanner scanner = new Scanner(System.in);
		Categorie[] categories = Categorie.values();
		int fini = 0;
		while ( fini == 0) {
			System.out.println("Vous ajoutez un Produit \n\n");
			System.out.println("Quel est le nom du produit : ");
			nom  = scanner.nextLine();
			System.out.println("\n Quelle est la description du produit : ");
			description  = scanner.nextLine();
			System.out.println("\n Quelle est la quantité minimale du produit : ");
			quteMin  = scanner.nextInt();
			System.out.println("\n Quelle est la quantité optimale du produit : ");
			quteOpti  = scanner.nextInt();
			System.out.println("\n Voici les categories, entrez le numéro corespondant à la catégorie souaithée :\n");
			int i = 1;
			for (Categorie categorie : Categorie.values()) {
				System.out.print(i + " "+ categorie + "\n");
				i++;
			}
			int cat = scanner.nextInt();
			while (cat < 1 || cat > 16) {
				System.out.println("\n Veullier rentrer une valeur entre 1 et 16 compris  :");
				cat = scanner.nextInt();
			}
			categorie = categories[cat-1];
			System.out.println("\n Si vous voullez recomencer entrez 0 sinon entrez 1 pour valider:");
			fini = scanner.nextInt();
		}
	ajouter(conn);
	}

	public void supprimer (Connection conn) {
		Scanner scanner = new Scanner(System.in);
		String sql;
		PreparedStatement pstmt;
		System.out.println("Quel est le nom du produit à supprimer ? \n");
		nom = scanner.nextLine();
		sql = "DELETE FROM Produit WHERE nomProd = "+nom+";";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	
	}

	public void modifier (Connection conn) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Bienvenue sur l'espace modification Produit !\n");
		System.out.println("Que  voullez vous modifier ? Renter le numéro corespondant.\n\n"); 
		System.out.println("0 : Retourner a l'accueil  \n");
		System.out.println("1 : nom \n");
		System.out.println("2 : description \n"); 
		System.out.println("3 : quantité minimale en stock \n"); 
		System.out.println("4 : quantité optimale en stock \n");  

		int NUM = scanner.nextInt();

		System.out.println("\n Quel est le nom actuel du produit : "); 
		nom = scanner.nextLine();
		String sql;
		PreparedStatement pstmt;

		switch (NUM ) {
		case 0 : Afficher x = new Afficher();
		x.affichagePrinc(conn);
		break;
		case 1 : 
			System.out.println("Quel est le nouveau nom \n");	 
			String nouvnom = scanner.nextLine();
			sql = "UPDATE Produit SET nom = '" + nouvnom + "' WHERE nom = "+nom +" ;";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 

			break;
		case 2 : 
			System.out.println("Quelle est la nouvelle description \n");
			description  = scanner.nextLine();

			sql = "UPDATE Produit SET description = '" + description + "' WHERE nom = "+ nom +" ;";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 

			break;
		case 3 : 
			System.out.println("Quelle est la nouvelle quandité minimale \n");
			quteMin = scanner.nextInt();

			sql = "UPDATE Produit SET quteMin = " + quteMin + "WHERE nom= "+ nom+" ;";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 

			break;
		case 4 : 
			System.out.println("Quelle est la nouvelle quandité Optimale \n");
			quteOpti= scanner.nextInt();

			sql = "UPDATE Produit SET quteOpti= " + quteOpti+ "WHERE nom= "+ nom+" ;";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 
			break;		

		}
	
	}
}