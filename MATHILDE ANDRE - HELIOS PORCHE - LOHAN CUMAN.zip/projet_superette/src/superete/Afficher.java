package superete;

import java.sql.*;
import java.util.Scanner;

public class Afficher {
	
	
	public Afficher() {
		super();
	}
	public void affichagePrinc(Connection conn) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Bienvenue sur votre superette !\n");
		System.out.println("Où voullez vous aller ? Renter le numéro corespondant.\n\n");
		System.out.println("1 : Zone Achat \n");
		System.out.println("2 : Zone Fournisseur \n");
		System.out.println("3 : Zone Produit \n");
		System.out.println("4 : Zone Vente \n");
		int NUM = scanner.nextInt();
		while ( NUM<1 || NUM>4) {
			System.out.println("Recommencer le numéro n'est pas compris entre 1 et 4 \n");	
			 NUM = scanner.nextInt();
		}
		switch (NUM ) {
		case 1 : ZoneAchat(conn);
		break;
		case 2 : ZoneFournisseur(conn);
		break;
		case 3 : ZoneProduit(conn);
		break;
		case 4 : ZoneVente(conn);
		break;
		}
		 
	}
// Zone achat et les fonction quui vont avec il manque ajouter

	public void ZoneAchat(Connection conn) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Bienvenue sur l'espace Achat !\n");
		System.out.println("Où voullez vous aller ? Renter le numéro corespondant.\n\n");
		System.out.println("0 : Retourner a l'accueil  \n");
		System.out.println("1 : Liste des contrats/achats \n");
		System.out.println("2 : Ajouter un contrat  \n"); //ajouter un contrat en meme temps un achat et produit stocké
		int NUM = scanner.nextInt();
		while ( NUM<0 || NUM>2) {
			System.out.println("Recommencer le numéro n'est pas compris entre 0 et 2 \n");	
			 NUM = scanner.nextInt();
		}
		switch (NUM ) {
		case 0 : affichagePrinc(conn);
		break;
		case 1 : affichageAchatContrat(conn);
		break;
		case 2 :
			Contrat x = new Contrat();
			x.demandeAjout(conn);
		break;
		}
		
	}
	public void  affichageAchatContrat(Connection conn) {
	Scanner scanner = new Scanner(System.in);
		
		System.out.println("Bienvenue sur l'espace Achat !\n");
		System.out.println("Où voullez vous aller ? Renter le numéro corespondant.\n\n");
		System.out.println("0 : Retourner a l'accueil  \n");
		System.out.println("1 : Liste des achats \n");
		System.out.println("2 : Liste des contrats \n"); //ajouter un contrat en meme temps un achat et produit stocké
		int NUM = scanner.nextInt();
		while ( NUM<0 || NUM>2) {
			System.out.println("Recommencer le numéro n'est pas compris entre 0 et 2 \n");	
			 NUM = scanner.nextInt();
		}
		switch (NUM ) {
		case 0 : affichagePrinc(conn);
		break;
		case 1 : affichageContrat(conn);
		break;
		case 2 : affichageAchat(conn);
		break;
		}	
		 
	}
	public void affichageContrat(Connection conn) {
		
		String sql = "SELECT idContrat, prix, nomProd, SIRET, description, dateDebut, dateFin FROM Contrat";
        Statement stmt;
        
		try {
	
        stmt = conn.createStatement();	
        ResultSet rs = stmt.executeQuery(sql); 
            // Afficher les colonnes pour chaque ligne du résultat
            System.out.println("Liste des produits :");
            while (rs.next()) {
                int id = rs.getInt("idContrat");
                double prix = rs.getDouble("prix");
                String typeProd = rs.getString("nomProd");
                int siret = rs.getInt("SIRET");
                String description = rs.getString("description");
                Date debut = rs.getDate("dateDebut");
                Date fin = rs.getDate("dateFin");

                System.out.println("ID: " + id + ", Prix: " + prix + ", Produit: " + typeProd+", SIRET: " + siret +", Description: " + description +", Date de début: " + debut +", Date de fin: " + fin +"\n");
            }}
            catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
		 affichageAchatContrat( conn);
        }
public void affichageAchat(Connection conn) {
		
		String sql = "SELECT idAchat, idContrat, prix, dateAchat, datePeremption FROM Contrat";
        Statement stmt;
        
		try {
	
        stmt = conn.createStatement();	
        ResultSet rs = stmt.executeQuery(sql); 
            // Afficher les colonnes pour chaque ligne du résultat
            System.out.println("Liste des produits :");
            while (rs.next()) {
                int id = rs.getInt("idAchat");
                int idV2 = rs.getInt("idContrat");
                double prix = rs.getInt("prix");
                Date achat = rs.getDate("dateAchat");
                Date peremption = rs.getDate("datePeremption");

                System.out.println("IDachat: " + id + ", IDcontrat: " + idV2 + ", Prix: " + prix+", Date de l'achat: " + achat +", Date de peremtion: " + peremption +"\n");
            }}
            catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
		 affichageAchatContrat(conn);
        }
	
// zone entreprise et les fonction qui vont avec il va manque ajouter 

public void ZoneFournisseur(Connection conn) {
	Scanner scanner = new Scanner(System.in);
	
	System.out.println("Bienvenue sur l'espace fournisseur !\n");
	System.out.println("Où voullez vous aller ? Renter le numéro corespondant.\n\n");
	System.out.println("0 : Retourner a l'accueil  \n");
	System.out.println("1 : Liste des fournisseurs \n");
	System.out.println("2 : Liste des contact  \n"); 
	System.out.println("3 : Zone entreprise  \n"); 
	System.out.println("4 : Zone contact   \n"); 
	int NUM = scanner.nextInt();
	while ( NUM<0 || NUM>4) {
		System.out.println("Recommencer le numéro n'est pas compris entre 0 et 4 \n");	
		 NUM = scanner.nextInt();
	}
	switch (NUM ) {
	case 0 : affichagePrinc(conn);
	break;
	case 1 : zoneEntreprise(conn);
	break;
	case 2 : affichageContact(conn);
	break;
	}
	 
}
	
	public void zoneEntreprise(Connection conn) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Bienvenue sur l'espace Entreprise !\n");
		System.out.println("Où voullez vous aller ? Renter le numéro corespondant.\n\n");
		System.out.println("0 : Retourner a l'accueil  \n");
		System.out.println("1 : Liste des Entreprises \n");
		System.out.println("2 : Ajouter une entreprise  \n"); 
		System.out.println("3 : Modifier une entreprise \n"); 
		System.out.println("4 : Supprimer une entreprise  \n"); 
		int NUM = scanner.nextInt();
		while ( NUM<0 || NUM>4) {
			System.out.println("Recommencer le numéro n'est pas compris entre 0 et 4 \n");	
			 NUM = scanner.nextInt();
		}
		switch (NUM ) {
		case 0 : affichagePrinc(conn);
		break;
		case 1 : affichageEntreprise(conn);
		break;
		case 2 : 
			Entreprise x = new Entreprise();
			x.demandeAjout(conn);
		break;
		case 3 : 
			Entreprise y = new Entreprise();
			y.modifier(conn);
		break;
		case 4 : 
			Entreprise z = new Entreprise();
			z.demandeAjout(conn);
		break;
		}
		
		
	}
	public void affichageEntreprise(Connection conn) {
		String sql = "SELECT SIRET, nomEntreprise, mail, adresse FROM Entreprise";
        Statement stmt;
        
		try {
	
        stmt = conn.createStatement();	
        ResultSet rs = stmt.executeQuery(sql); 
            // Afficher les colonnes pour chaque ligne du résultat
            System.out.println("Liste des Fournisseurs :");
            while (rs.next()) {
                int siret = rs.getInt("SIRET");
                String entreprise = rs.getString("nomEntreprise");
                String mail = rs.getString("mail");
                String adresse = rs.getString("adresse");

                System.out.println("SIRET: " + siret + ", Nom de l'entreprise: " + entreprise+ ", Mail: " + mail+", Adresse: " + adresse +"\n");
            }}
            catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		};
    		ZoneFournisseur(conn);
	}
	public void affichageContact(Connection conn) {
		String sql = "select telContact, nom, prenom, email, FonctionContact.fonction, Entreprise.nomEntreprise \r\n"
				+ "	from Contact join FonctionContact using (telContact) join  Entreprise using (SIRET);";
        Statement stmt;
        
		try {
	
        stmt = conn.createStatement();	
        ResultSet rs = stmt.executeQuery(sql); 
            // Afficher les colonnes pour chaque ligne du résultat
            System.out.println("Liste des produits :");
            while (rs.next()) {
                int tel = rs.getInt("telContact");
                String nom = rs.getString("nom");
                String prenom= rs.getString("prenom");
                String email = rs.getString("email");
                String fonction = rs.getString("FonctionContact.fonction");
                String entreprise= rs.getString("Entreprise.nomEntreprise");
                
                System.out.println("Num de tel: " + tel + ", Nom: " + nom + ", Prenom: " + prenom+", Mail: " + email +", Fonction: " + fonction +", Nom de l'entreprise associé: " + entreprise +"\n");
            }}
            catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
		ZoneFournisseur(conn);
	}
	
	
	// Zone Vente 
	public void ZoneVente(Connection conn) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Bienvenue sur l'espace Achat !\n");
		System.out.println("Où voullez vous aller ? Renter le numéro corespondant.\n\n");
		System.out.println("0 : Retourner a l'accueil  \n");
		System.out.println("1 : Liste des ventes \n");
		System.out.println("2 : Ajouter une vente   \n"); //ajouter un contrat en meme temps un achat et produit stocké
		int NUM = scanner.nextInt();
		while ( NUM<0 || NUM>2) {
			System.out.println("Recommencer le numéro n'est pas compris entre 0 et 2 \n");	
			 NUM = scanner.nextInt();
		}
		switch (NUM ) {
		case 0 : affichagePrinc(conn);
		break;
		case 1 : affichageVente(conn);
		break;
		case 2 :
			Vente x = new Vente();
			x.demandeAjout(conn);
		break;
		}
		 
		
	}
	public void affichageVente(Connection conn){
	
		String sql = "SELECT dateVente, num_lot, nomProd, prixFinal, quantite, commentaire FROM Vente";
        Statement stmt;
        
		try {
	
        stmt = conn.createStatement();	
        ResultSet rs = stmt.executeQuery(sql); 
            // Afficher les colonnes pour chaque ligne du résultat
            System.out.println("Liste des Fournisseurs :");
            while (rs.next()) {
                Date date = rs.getDate("dateVente");
                int lot  = rs.getInt("num_lot");
                String produit = rs.getString("nomProd");
                int prix  = rs.getInt("prixFinal");
                int quantite  = rs.getInt("quantite");
                String commentaire  = rs.getString("commentaire");
                
                System.out.println("Date de la vente: " + date + ", Lot : " + lot + ", Produit : " + produit +", Prix total: " + prix  +", Quantité " + quantite  +", Commentaire " + commentaire  +"\n");
            }}
            catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
		 ZoneVente(conn) ;
	}
		
	
	// Zone Produit 
	
	
	public void ZoneProduit(Connection conn ) {
		
	Scanner scanner = new Scanner(System.in);
		
		System.out.println("Bienvenue sur l'espace Achat !\n");
		System.out.println("Où voullez vous aller ? Renter le numéro corespondant.\n\n");
		System.out.println("0 : Retourner a l'accueil  \n");
		System.out.println("1 : Liste des Produits \n");
		System.out.println("2 : Liste des Produits Stockés \n");
		System.out.println("3 : Ajouter un produit    \n"); //ajouter un contrat en meme temps un achat et produit stocké
		int NUM = scanner.nextInt();
		while ( NUM<0 || NUM>2) {
			System.out.println("Recommencer le numéro n'est pas compris entre 0 et 2 \n");	
			 NUM = scanner.nextInt();
		}
		switch (NUM ) {
		case 0 : affichagePrinc(conn);
		break;
		case 1 : affichageProduit(conn);
		break;
		case 2 : affichageProduitStocke(conn);
		break;
		case 3 :
			Produit x = new Produit();
			x.demandeAjout(conn);
		break;
		}
	 
	}
	
	
	public void affichageProduit(Connection conn){
		
		String sql = "SELECT nomProd, quteOpti, quteMin, categorie, description FROM Produit";
        Statement stmt;
        
		try {
	
        stmt = conn.createStatement();	
        ResultSet rs = stmt.executeQuery(sql); 
            // Afficher les colonnes pour chaque ligne du résultat
            System.out.println("Liste des Fournisseurs :");
            while (rs.next()) {
                String nom = rs.getString("nomProd");
                int quteOpti  = rs.getInt("quteOpti");
                int quteMin = rs.getInt("quteMin");
                String categorie = rs.getString("categorie");
                String description  = rs.getString("desccription");
                
                System.out.println("Nom produit: " + nom + ", Quantité Opti : " + quteOpti+ ", Quantité Min : " + quteMin +", Catégorie: " + categorie  +", Description " + description  +"\n");
            }}
            catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
		 ZoneProduit(conn) ;
	}
	
public void affichageProduitStocke(Connection conn){
		
		String sql = "SELECT num_lot, nomProd, qute, prixVente, idAchat FROM Produit";
        Statement stmt;
        
		try {
	
        stmt = conn.createStatement();	
        ResultSet rs = stmt.executeQuery(sql); 
            // Afficher les colonnes pour chaque ligne du résultat
            System.out.println("Liste des Fournisseurs :");
            while (rs.next()) {
                int lot= rs.getInt("num_lot");
                String nom  = rs.getString("nomProd");
                int qute = rs.getInt("qute");
                int prix = rs.getInt("prix");
                int achat  = rs.getInt("idAchat");
                
                System.out.println("Nom produit: " + nom + ", Quantité  : " + qute+ ", Lot : " + lot +", Prix : " + prix  +", id Achat " + achat  +"\n");
            }}
            catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
		 ZoneProduit(conn) ;
	}

}
