package superete;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Achat implements Ajouter, Modifier, Supprimer {
	public int id_Achat;
	public int id_Contrat;
	public double prix;
	public Date dateAchat;
	public Date datePeremption;

 
	
	
public Achat() {
		super();
		id_Achat = -1;
		id_Contrat = -1;
		prix = -1;
		dateAchat = null;
		datePeremption = null;
	}

public int ajouter(Connection conn) {

	String sql = "INSERT INTO Achat(idAchat, idContrat, prix, dateAchat, datePeremption) VALUES(?,?,?,?,?)";
	try ( PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
		pstmt.setInt(1, id_Achat);
		pstmt.setInt(2,id_Contrat); 
		pstmt.setDouble(3, prix); 
		pstmt.setDate(4,dateAchat );
		pstmt.setDate(5, datePeremption); 
		
		int insertedRow = pstmt.executeUpdate(); //remplace les ? par les champs
		if (insertedRow > 0) { //si ça marche on return 1
			ResultSet rs = pstmt.getGeneratedKeys(); 
			if (rs.next()) {
				return rs.getInt(1);
			}
			} 
		} catch (SQLException e) {	
	}
	return 0;
	 
}
public void demandeAjout(Connection conn) {

Scanner scanner = new Scanner(System.in);
int fini = 0;
while ( fini == 0) {
System.out.println("Vous ajoutez un achat \n\n");
System.out.println("Quel est le numéro unique de l'achat : ");
id_Achat  = scanner.nextInt();
System.out.println("\n Quel est l'identifiant du contrat : ");
id_Contrat  = scanner.nextInt();
System.out.println("\n Quelle le prix de l'achat : ");
prix = scanner.nextDouble();
System.out.println("\n Si vous voullez recomencer entrez 0 sinon entrez 1 pour valider:");
fini = scanner.nextInt();
}
ajouter(conn);
}


public void supprimer (Connection conn) {
	Scanner scanner = new Scanner(System.in);
	String sql;
	PreparedStatement pstmt;
	System.out.println("Quel est l'id de l'achat a supprimer ? \n");
	id_Achat  = scanner.nextInt();
	sql = "DELETE FROM Achat WHERE idAchat = "+id_Achat+";";
	try {
		pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	} 

	}

public void modifier (Connection conn) {
	Scanner scanner = new Scanner(System.in);

	System.out.println("Bienvenue sur l'espace modification Achat!\n");
	System.out.println("Que  voullez vous modifier ? Renter le numéro corespondant.\n\n"); 
	System.out.println("0 : Retourner a l'accueil  \n");
	System.out.println("1 : prix  \n");
	System.out.println("2 : date de peremption  \n"); 
 
	int NUM = scanner.nextInt();
	
	System.out.println("\n Quel est l'id de l'achat: "); 
	id_Achat   = scanner.nextInt();
	String sql;
	 PreparedStatement pstmt;
	 
	switch (NUM ) {
	case 0 : Afficher x = new Afficher();
			x.affichagePrinc(conn);
	break;
	case 1 : 
		System.out.println("Quel est le nouveaau prix \n");	 
		prix  = scanner.nextInt();
		sql = "UPDATE Achat SET prix = " + prix  + "WHERE idAchat = "+ id_Achat +" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 2 : 
		System.out.println("Quelle est la nouvelle date (yyyy-MM-dd) \n");
		String date  = scanner.nextLine();
		
		sql = "UPDATE Achat SET datePeremption = " + date + "WHERE idAchat = "+ id_Achat +" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	}

	}

}
