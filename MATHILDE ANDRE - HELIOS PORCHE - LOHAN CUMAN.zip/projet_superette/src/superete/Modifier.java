package superete;

import java.sql.*;

public interface Modifier {
	public void modifier(Connection conn);
}
