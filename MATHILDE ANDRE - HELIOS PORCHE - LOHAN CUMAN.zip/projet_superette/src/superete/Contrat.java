package superete;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Contrat  implements Ajouter, Modifier, Supprimer {
	public int id_Contrat;
	public double prix;
	public String typeProd;
	public int SIRET;
	public String description;
	public Date debut;
	public Date fin;
	//public boolean fini; on peut le faire avec date du jour et date fin contrat 


	
	
	
public int ajouter(Connection conn) {
	Achat x = new  Achat();
	x.demandeAjout(conn);
	String sql = "INSERT INTO Contrat(idContrat, prix, nomProd, SIRET, description, dateDebut, dateFin) VALUES(?,?,?,?,?,?,?)";
	try ( PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
		pstmt.setInt(1, id_Contrat);
		pstmt.setDouble(2,prix); 
		pstmt.setString(3, typeProd); 
		pstmt.setInt(4, SIRET); 
		pstmt.setString(5, description); 
		pstmt.setDate(6,debut);
		pstmt.setDate(7,fin);
		int insertedRow = pstmt.executeUpdate(); //remplace les ? par les champs
		if (insertedRow > 0) { //si ça marche on return 1
			ResultSet rs = pstmt.getGeneratedKeys(); 
			if (rs.next()) {
				return rs.getInt(1);
			}
			} 
		} catch (SQLException e) {	
	}
	return 0;
	 
}

public Contrat() {
		super();
		this.id_Contrat = -1;
		this.prix = -1;
		this.typeProd = null;
		SIRET = -1;
		this.description = "";
		this.debut = null;
		this.fin = null;
	}
public void demandeAjout(Connection conn) {

Scanner scanner = new Scanner(System.in);
int fini = 0;
while ( fini == 0) {
System.out.println("Vous ajoutez un Contrat\n\n");
System.out.println("Quel est l'identifiant du contrat : ");
id_Contrat  = scanner.nextInt();
System.out.println("\n Quel est le prix d'achat décidé : ");
prix  = scanner.nextDouble();
System.out.println("\n Quelle est le type de produit du contrat : ");
typeProd = scanner.nextLine();
System.out.println("\n Quelle est le numéro de SIRET de l'entreprise : ");
SIRET  = scanner.nextInt();
System.out.println("\n Description :\n");
description  = scanner.nextLine();
System.out.println("\n Date de début au format yyyy-MM-dd :\n");
String start  = scanner.nextLine();
debut = Date.valueOf(start);
System.out.println("\n Date de fin au format yyyy-MM-dd :\n");
String end  = scanner.nextLine();
debut = Date.valueOf(end);

System.out.println("\n Si vous voullez recomencer entrez 0 sinon entrez 1 pour valider:");
fini = scanner.nextInt();
}
ajouter(conn);
}

public void supprimer (Connection conn) {
	Scanner scanner = new Scanner(System.in);
	String sql;
	PreparedStatement pstmt;
	System.out.println("Quel est l'id du contrat a supprimer ? \n");
	id_Contrat  = scanner.nextInt();
	sql = "DELETE FROM Contrat WHERE idContrat = "+id_Contrat+";";
	try {
		pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		pstmt.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	} 

	}

public void modifier (Connection conn) {
	Scanner scanner = new Scanner(System.in);

	System.out.println("Bienvenue sur l'espace modification Contrat !\n");
	System.out.println("Que  voullez vous modifier ? Renter le numéro corespondant.\n\n"); 
	System.out.println("0 : Retourner a l'accueil  \n");
	System.out.println("1 : prix  \n");
	System.out.println("2 : produit  \n"); 
	System.out.println("3 : SIRET  \n"); 
	System.out.println("4 : description \n"); 
	System.out.println("5 : Date de debut  \n"); 
	System.out.println("6 : Date de fin  \n"); 
	int NUM = scanner.nextInt();
	
	System.out.println("\n Quel est l'id du contrat: "); 
	id_Contrat   = scanner.nextInt();
	String sql;
	 PreparedStatement pstmt;
	 
	switch (NUM ) {
	case 0 : Afficher x = new Afficher();
			x.affichagePrinc(conn);
	break;
	case 1 : 
		System.out.println("Quel est le nouveaau prix \n");	 
		prix  = scanner.nextInt();
		sql = "UPDATE Achat SET prix = " + prix  + "WHERE idContrat"+id_Contrat+" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 2 : 
		System.out.println("Quelle est le  nouveau produit \n");
		typeProd = scanner.nextLine();
		
		sql = "UPDATE Contrat SET nomProd ='"+typeProd+ "'WHERE idContrat\"+id_Contrat+\" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 3 : 
		System.out.println("Quelle est le  nouveau SIRET \n");
		SIRET = scanner.nextInt();
		
		sql = "UPDATE Contrat SET SIRET ="+SIRET+ "WHERE idContrat\"+id_Contrat+\" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 4 : 
		System.out.println("Quelle est la nouvelle description \n");
		description = scanner.nextLine();
		
		sql = "UPDATE Contrat SET description ='"+description+ "'WHERE idContrat\"+id_Contrat+\" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 5 : 
		System.out.println("Quelle est la nouvelle date de Début (yyyy-MM-dd) \n");
		String dateD  = scanner.nextLine();
		
		sql = "UPDATE Contrat SET dateDebut ="+dateD+ "WHERE idContrat\"+id_Contrat+\" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	case 6 : 
		System.out.println("Quelle est la nouvelle date de Début (yyyy-MM-dd) \n");
		String dateF  = scanner.nextLine();
		
		sql = "UPDATE Contrat SET dateFin ="+dateF+ "WHERE idContrat\"+id_Contrat+\" ;";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
			
	break;
	}

	}
}

