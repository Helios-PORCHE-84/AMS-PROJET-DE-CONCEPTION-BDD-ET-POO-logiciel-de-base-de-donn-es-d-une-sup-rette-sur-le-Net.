package superete;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Vente implements Ajouter, Modifier, Supprimer {

	public int id_Vente;
	public Date date;
	public int numLot;
	public String nomProd;
	public int quantite;
	public double prixFinal; //si réductions et tout, si gratuit...
	public String commentaire; //Vendu, périmé, endommagé,...



	public Vente() {
		super();
		id_Vente = -1;
		date =  null;
		numLot =  -1;
		nomProd = "";
		quantite = -1;
		prixFinal= -1;
		commentaire = "";
	}

	public int ajouter(Connection conn) {

		String sql = "INSERT INTO Vente(dateVente, num_lot, nomProd, prixFinal, quantite, commentaire) VALUES(?,?,?,?,?,?)";
		try ( PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
			pstmt.setDate(1, date);
			pstmt.setInt(2,numLot); 
			pstmt.setString(3, nomProd); 
			pstmt.setInt(4, quantite); 
			pstmt.setDouble(5, prixFinal); 
			pstmt.setString(6,commentaire);
			int insertedRow = pstmt.executeUpdate(); //remplace les ? par les champs
			if (insertedRow > 0) { //si ça marche on return 1
				ResultSet rs = pstmt.getGeneratedKeys(); 
				if (rs.next()) {
					return rs.getInt(1);
				}
			} 
		} catch (SQLException e) {	
		}
		return 0;

	}
	public void demandeAjout(Connection conn) {

		Scanner scanner = new Scanner(System.in);
		int fini = 0;
		while ( fini == 0) {
			System.out.println("Vous ajoutez une Vente\n\n");
			System.out.println("Quel est le numéro de lot du(des) produit(s) vendu(s) : ");
			numLot  = scanner.nextInt();
			System.out.println("\n Quel est le nom du produit : ");
			nomProd  = scanner.nextLine();
			System.out.println("\n Quelle est la quantité vendue : ");
			quantite = scanner.nextInt();
			System.out.println("\n Quelle est le prix final de la vente (en prenant compte des réductions appliqués ou non) : ");
			prixFinal  = scanner.nextDouble();
			System.out.println("\n Commentaire (réduction, produit endommagé : vente à 0) , ect... :\n");
			commentaire  = scanner.nextLine();
			System.out.println("\n Si vous voullez recomencer entrez 0 sinon entrez 1 pour valider:");
			fini = scanner.nextInt();
		}
		scanner.close();
	}
	public void supprimer (Connection conn) {
		Scanner scanner = new Scanner(System.in);
		String sql;
		PreparedStatement pstmt;
		System.out.println("Quel est l'id de la vente à supprimer ? \n");
		id_Vente = scanner.nextInt();
		sql = "DELETE FROM Vente WHERE id_Vente = "+id_Vente+";";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		scanner.close();
	}

	public void modifier (Connection conn) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Bienvenue sur l'espace modification Produit !\n");
		System.out.println("Que  voullez vous modifier ? Renter le numéro corespondant.\n\n"); 
		System.out.println("0 : Retourner a l'accueil  \n");
		System.out.println("1 : Quantité \n");
		System.out.println("2 : Prix final \n"); 
		System.out.println("3 : commentaire \n");   

		int NUM = scanner.nextInt();

		System.out.println("\n Quel est l'id de vente : "); 
		id_Vente = scanner.nextInt();
		String sql;
		PreparedStatement pstmt;

		switch (NUM ) {
		case 0 : Afficher x = new Afficher();
		x.affichagePrinc(conn);
		break;
		case 1 : 
			System.out.println("Quel est la nouvelle quantité \n");	 
			quantite = scanner.nextInt();
			sql = "UPDATE Vente SET quantite = " + quantite+ "WHERE id_Vente = "+id_Vente+" ;";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 

			break;
		case 2 : 
			System.out.println("Quel est le nouveau prix final\n");	 
			prixFinal = scanner.nextInt();
			sql = "UPDATE Vente SET prixFinal = " + prixFinal+ "WHERE id_Vente = "+id_Vente+" ;";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 

			break;
		case 3: 
			System.out.println("Quel est le nouveau commentaire\n");	 
			prixFinal = scanner.nextInt();
			sql = "UPDATE Vente SET commentaire = '" + commentaire + "' WHERE id_Vente = "+id_Vente+" ;";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			} 

			break;
		}
		scanner.close();
	}
}
