package superete;
import java.sql.*;

public class CreerBDD {

	
	
	public CreerBDD() {
		super();
	}


	public static boolean bddExistante(Connection connection, String table) {
		String requeteTest = "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'Produit');";
		boolean existe = false;
		try (PreparedStatement ps = connection.prepareStatement(requeteTest)) {
            ps.setString(1, table);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    existe = rs.getBoolean(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return existe;
	}
	
	
	public static void creerBDD(Connection connection) {
		String Produit = "Produit";
		if (!bddExistante(connection, Produit)) {
			creerTable(connection);
		}
	}

	public static void creerTable(Connection connection) {
		String cmd = "create table Produit(\r\n"
				+ "	nomProd varchar(40),\r\n"
				+ "	quteOpti integer,\r\n"
				+ "	categorie varchar(20),\r\n"
				+ "	description varchar(400));\r\n"
				+ "	\r\n"
				+ "create table Vente(\r\n"
				+ "	dateVente date,\r\n"
				+ "	num_lot integer references ProduitStocke,\r\n"
				+ "	nomProd varchar(40) references Produit,\r\n"
				+ "	prixFinal numeric(6,2),\r\n"
				+ "	quantite integer,\r\n"
				+ "	commentaire varchar(400));\r\n"
				+ "\r\n"
				+ "create table ProduitStocke(\r\n"
				+ "	num_lot integer,\r\n"
				+ "	nomProd varchar(40) references Produit,\r\n"
				+ "	qute integer,\r\n"
				+ "	prixVente numeric(6,2),\r\n"
				+ "	idAchat integer references Achat);\r\n"
				+ "\r\n"
				+ "create table Achat(\r\n"
				+ "	idAchat integer primary key,\r\n"
				+ "	idContrat integer references Contrat,\r\n"
				+ "	prix numeric(6,2),\r\n"
				+ "	dateAchat date,\r\n"
				+ "	datePeremption date);\r\n"
				+ "\r\n"
				+ "create table Contrat(\r\n"
				+ "	idContrat integer primary key,\r\n"
				+ "	prix numeric(6,2),\r\n"
				+ "	nomProd varchar(40) references Produit,\r\n"
				+ "	SIRET integer references Entreprise,\r\n"
				+ "	description varchar(400)\r\n"
				+ "	dateDebut date,\r\n"
				+ "	dateFin date);\r\n"
				+ "	\r\n"
				+ "create table Entreprise(\r\n"
				+ "	SIRET INTEGER primary key,\r\n"
				+ "	nomEntreprise varchar(100),\r\n"
				+ "	mail varchar(200),\r\n"
				+ "	adresse varchar (500));\r\n"
				+ "	\r\n"
				+ "create table FonctionContact(\r\n"
				+ "	SIRET integer references Entreprise,\r\n"
				+ "	telContact varchar(15) references Contact,\r\n"
				+ "	fonction varchar (40));\r\n"
				+ "\r\n"
				+ "create table Contact(\r\n"
				+ "	telContact varchar(15) primary key,\r\n"
				+ "	nom varchar(40),\r\n"
				+ "	prenom varchar(40),\r\n"
				+ "	email varchar(200));";
	}
	
	public static void executerSQL(Connection connection, String commande) {
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(commande);
			stmt.close();
		}
		catch(Exception e) {}
	}
}



